# Infografía 2

Esta infografía de eldiario.es habla sobre las tendencias de uso y acceso a internet según la edad. Para ello, ha utilizado un gráfico de tipo telaraña dividido. La edad se encuentra dividida en 6 sectores y colores, 
desde los 16 años a los 74. De esta forma, se observa cómo la telaraña es más grande, en general, para el sector de los más jóvenes (de 16 a 24 años) y muy pequeña e incluso casi inexistente en la línea azul, es 
decir, la que representa el uso que hacen de internet las personas de 65 a 74 años. Las clasificaciones son los 5 usos más típicos de internet: videollamar, buscar trabajo, recibir o enviar emails, usar redes sociales 
y leer noticias. En mi opinión, la infografía está clara y el formato de la telaraña es original y muy apropiado y visual para representar estos datos. Sin embargo, como punto negativo, resaltaría que la franja de 
edad solo llegue hasta los 74 años, ya que me gustaría conocer los usos de internet (por muy bajos que sean) de las personas que superan esa edad.

https://static.eldiario.es/clip/8b9de061-7a07-44b6-ab0c-147a66dfba58_16-9-aspect-ratio_default_0.jpg
