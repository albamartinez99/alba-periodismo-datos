# Ejercicios periodismo de datos
Estos son los ejercicios que vamos a hacer en clase.
1. [Infografía](infografia.md)
2. Comentario crítico de infografía
3. Generar infografía
4. Generar web
